#include <string>
std::string warning(std::string);
std::string notice(std::string);
