#include "K.h"

const char K::typeInt[7] = "INT";
const char K::typeString[7] = "STRING";
const char K::typeDouble[7] = "DOUBLE";
const char K::typeChar[7] = "CHAR";
