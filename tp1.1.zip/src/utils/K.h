#ifndef SRC_UTILS_K_H_
#define SRC_UTILS_K_H_

class K {
public:
	static const char typeInt[7];
	static const char typeString[7];
	static const char typeDouble[7];
	static const char typeChar[7];
};

#endif
