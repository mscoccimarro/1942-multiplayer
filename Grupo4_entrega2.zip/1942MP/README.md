# 1942MP

### Enunciados

[Primera entrega](https://docs.google.com/viewer?a=v&pid=forums&srcid=MDQ3NTE0MTc4MzEwNjY3NjQwMTEBMTA4MjY3MzI1NDY4MDE1MjU3NTkBY3ZoWWVrVXZCQUFKATAuMQEBdjI)

[Segunda entrega](https://docs.google.com/viewer?a=v&pid=forums&srcid=MDQ3NTE0MTc4MzEwNjY3NjQwMTEBMDk4NDY1ODg4Njc4MDA0MzAzMjABMmFfcFZ3dFlCZ0FKATAuMQEBdjI)
