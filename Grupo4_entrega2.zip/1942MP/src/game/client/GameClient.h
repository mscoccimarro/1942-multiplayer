#ifndef INC_1942MP_GAMECLIENT_H
#define INC_1942MP_GAMECLIENT_H

#include "../../libs/socket/Client.h"

class GameClient {
private:
    Client client;
};

#endif
