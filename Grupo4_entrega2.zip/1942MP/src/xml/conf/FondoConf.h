//#ifndef INC_1942MP_FONDOCONF_H
//#define INC_1942MP_FONDOCONF_H
//
//class FondoConf {
//public:
//    string spriteID;
//};
//
//#endif
