#ifndef MISILCONF_H_
#define MISILCONF_H_

#include "string"

using namespace std;

typedef struct MisilConf {
    int velocidadDisparos;
    char disparosSpriteID[20];
} MisilConf;

#endif
