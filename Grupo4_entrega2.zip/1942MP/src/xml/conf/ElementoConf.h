#ifndef INC_1942MP_ELEMENTOCONF_H
#define INC_1942MP_ELEMENTOCONF_H

#include "string"
#include "vector"

using namespace std;

typedef struct ElementoConf {
    char spriteID[30];
    int x;
    int y;
} ElementoConf;

#endif
