#ifndef INC_1942MP_ESCENARIOCONF_H
#define INC_1942MP_ESCENARIOCONF_H

typedef struct EscenarioConf {
    int ancho;
    int alto;
    char fondo[30];
} EscenarioConf;

#endif
