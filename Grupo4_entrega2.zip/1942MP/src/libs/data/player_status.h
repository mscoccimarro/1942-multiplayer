#ifndef PLAYER_STATUS_H
#define PLAYER_STATUS_H
typedef struct PlayerStatus {
  char status;
} PlayerStatus;
#endif
