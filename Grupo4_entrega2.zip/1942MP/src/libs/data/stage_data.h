#ifndef STAGE_DATA_H
#define STAGE_DATA_H
typedef struct StageData {
  int offset;
} StageData;
#endif
