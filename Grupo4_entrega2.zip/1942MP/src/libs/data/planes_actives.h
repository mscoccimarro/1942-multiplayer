/*
 * planes_actives.h
 *
 *  Created on: 10 de may. de 2016
 *      Author: ramon
 */

#ifndef SRC_LIBS_DATA_PLANES_ACTIVES_H_
#define SRC_LIBS_DATA_PLANES_ACTIVES_H_

typedef struct PlanesActives {
  bool blue;
  bool red;
  bool green;
  bool yellow;
} PlanesActives;



#endif /* SRC_LIBS_DATA_PLANES_ACTIVES_H_ */
